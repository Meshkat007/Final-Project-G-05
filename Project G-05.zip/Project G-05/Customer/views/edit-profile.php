<?php include '../include/header.php'; ?>

<?php include '../Controller/updateProfileController.php'; ?>


<link rel="stylesheet" href="../assests/CSS/login.css">
<div class="container">
    <div class="my-content">
        <h5 class="font-weight-bold">Update Your Account</h5>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" name="logInForm" onsubmit="return validateForm()">
            <input type="text" id="userId" style="display: none;" value="<?php echo $_SESSION['myUser']; ?>" name="id">   
            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control form-control-sm" name="email" id="email">
                <?php if (isset($emailErr)) { ?>
                    <p style="color: red;"><?php echo $emailErr ?></p>
                <?php   } ?>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="text" class="form-control form-control-sm" name="password" id="pass">
                <?php if (isset($passErr)) { ?>
                    <p style="color: red;"><?php echo $passErr ?></p>
                <?php   } ?>
            </div>
            <div class="form-group">
                <label for="cpassword">Confirm Password</label>
                <input type="text" class="form-control form-control-sm" name="cpassword" id="cpass">
                <?php if (isset($cpasswordErr)) { ?>
                    <p style="color: red;"><?php echo $cpasswordErr ?></p>
                <?php   } ?>
            </div>
            <button class="btn btn-primary" type="submit">Update My Profile</button>
        </form>
        <h6 class="font-weight-bold" style="color: red; text-align:center">
            <?php if (isset($exist)) {
                echo $exist;
            } ?>
        </h6>
        <p style="text-align: center;">Don't wanna change anything?</p>
        <button class="btn btn-success"><a href="login.php" style="color:white;">Go To LogIn Page</a></button>
    </div>
</div>





<script> 
const userId = document.getElementById('userId').value;
const params = "id="+userId;

let xhr = new XMLHttpRequest();
xhr.open('POST', '../Controller/editProfileController.php', true);
xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');



xhr.send(params);

xhr.onload = function(){
  if(this.status==200){
    const user = JSON.parse(this.responseText);

    document.getElementById('email').value = user.email;
    document.getElementById('pass').value = user.password;
    document.getElementById('cpass').value = user.password;
  }
}



function validateForm(){
    let email = document.forms['logInForm']['email'].value;
    let password = document.forms['logInForm']['password'].value;
    if(email==""&&password==""){
        alert("email and password must be filled");
    }else if(email==""&&password!=""){
        alert("email is required");
    }else if(password==""&&email!=""){
        alert("password is required");
    }
}  




</script>

<?php include '../include/footer.php'; ?>