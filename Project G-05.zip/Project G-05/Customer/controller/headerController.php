<?php

session_start();

if(isset($_SESSION["myUser"])){

  $myUrl = 'edit-profile.php';
  $myText = 'Edit Profile';

}else{

  $myUrl = 'login.php';
  $myText = 'Login';

}
