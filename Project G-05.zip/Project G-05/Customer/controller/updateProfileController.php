<?php


$emailErr = $passErr = $cpasswordErr =  "";
$email = $password = "";
$exist ="";

if($_SERVER["REQUEST_METHOD"]=="POST"){
    if(empty($_POST["email"])){
        $emailErr = "email  is required!";
    }else{
        $email = $_POST["email"];
    }

    if(empty($_POST["password"])){
        $passErr ="password can not be empty";
    }else{
        $password = $_POST["password"];
    }

    if($_POST["password"]!==$_POST["cpassword"]){
        $cpasswordErr = "password does not match";
    }

    if(!empty($_POST["email"])&& !empty($_POST["password"])&&$_POST["password"]==$_POST["cpassword"]){
        $conn = new mysqli('localhost', 'root', '', 'restaurant');

        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }

        $sql = "update user set email = '{$_POST["email"]}', password = '{$_POST["password"]}' where id='{$_POST["id"]}'";  
        

        if ($conn->query($sql) === TRUE) {
            $exist = "Update product successfull";
          } else {
            $exist="Opps! I don't know why this error occourd but I Can not insert you as a user!";
        }
    }
}


