<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  $id = $_POST['id'];
  $conn = new mysqli('localhost', 'root', '', 'restaurant');

  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $sql = "select * from user where id = '{$id}'";
  $result  = $conn->query($sql);

  if ($result !== false && $result->num_rows > 0) {
      $user = $result->fetch_assoc();
  }

  echo json_encode($user);
}

