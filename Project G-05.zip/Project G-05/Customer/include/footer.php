<footer style="margin-top: 10em;">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <p>Copyright &copy; 2021 Nabil Sir</p>
            </div>
            <div class="col-md-4">
                <ul class="social-icons d-flex">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="#"><i class="fa fa-rss"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <p>Eta kon semister jani ?</p>
            </div>
        </div>
    </div>
</footer>

  </body>
</html>
