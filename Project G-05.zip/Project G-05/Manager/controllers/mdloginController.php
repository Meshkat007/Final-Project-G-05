<?php
    require_once 'models/db_config.php' ;    
    $username="";
    $err_username="";
	$name="";
    $err_name="";
    $password="";
    $err_password="";
	$phone="";
	$err_phone="";
	$email="";
	$err_email="";
    $type = "";
    $err_type="";
    $hasError=false;
    
        if (isset($_POST["sign_up"])){
            if (empty($_POST["username"])){
                $err_username="Username Required";
                $hasError=true;
            }
            elseif(strlen($_POST["username"])<6){
                $err_username="Username must contain at least 6 characters ";
                $hasError=true;
            }
            elseif(strpos($_POST["username"]," ")) {
                $err_username="space is not allowed";
                $hasError=true;
            }
            else{
                $username=htmlspecialchars($_POST["username"]);
                
            }
			 if(empty($_POST["name"]))
            {
                $hasError = true ;
                $err_name = "Name required!" ;
            }
            else 
            {
                $name = $_POST["name"] ;
            }
			
            if(empty($_POST["password"]))
            {
                $hasError = true ;
                $err_password = "Password required!" ;
            }
            else 
            {
                $password = $_POST["password"] ;
            }
			 if(empty($_POST["phone"])){
				 $err_phone="Insert Your Phone Number";
			 }
			 elseif(!is_numeric($_POST["phone"])){
			     $err_phone="[Phone number should contain Numeric values only]";
		     }
			 elseif(strlen($_POST["phone"])<11){
				 $err_phone="Phone Number Must Be 11 Charachter Long";
			 }
			 else{
				 $phone=$_POST["phone"];
			 }
			 
			 if(empty($_POST["email"])) {
                 $err_email = "Email is required";
             }
             elseif(!strpos($_POST["email"],"@")){
                 $err_email="[Email must contain @]";
             }            
             else {
                 $email =$_POST["email"];
             }

            if(empty($_POST["type"]))
            {
                $err_type="User type required";
                $hasError=true;
            }
            else
            {
                 $type=htmlspecialchars($_POST["type"]);
            }    
		
           if(!$hasError)
           {
              insertUser($username,$name,$password,$phone,$email,$type);
           }
        }
        
        if(isset($_POST["login"]))
        {
            
            if(empty($_POST["username"])){
                $err_username="Username Required";
                $hasError=true;
            }
            elseif(strlen($_POST["username"])<6){
                $err_username="Username must contain at least 6 characters ";
                $hasError=true;
            }
            elseif(strpos($_POST["username"]," ")) {
                $err_username="space is not allowed";
                $hasError=true;
            }
            else{
                $username=htmlspecialchars($_POST["username"]);
                
            }
			
            if(empty($_POST["password"]))
            {
                $hasError = true ;
                $err_password = "Password required!" ;
            }
            else 
            {
                $password = $_POST["password"] ;
            }
			
            if(isset($_POST['login']))
            {
                if(authentication($username,$password))
                {
                    header("Location: mdmanager.php") ;
                }
                echo "Invalid username or password" ;
                
            }
        }
    
    function insertUser($username,$name,$password,$phone,$email,$type)
    {
        $query = "INSERT INTO user VALUES (NULL,'$username','$name','$password','$phone','$email','$type')" ;
        
        execute($query) ;
    }
     
    function authentication($username,$password)
    {
        $query = "select * from user where username='$username' and password='$password'";
        $result = get($query) ;
        if(count($result)>0)
        {
			session_start();
                $username = $result[0];
                $_SESSION["loggedin"] = $username["username"];
                header("Location:mdmanager.php");
            }
            else{
                echo "UserName or PassWord is Incorrect";
            }
              
    } 
      function checkUsernamee($username){
		$query = "select * from user where username='$username'";
		$result=get($query);
		if(count($result) > 0){
			
			return "false";
		}
		return "true";
	}

?>