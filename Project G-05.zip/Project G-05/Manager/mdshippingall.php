<html>

	<head>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	</head>
	
		
<html>
<head>

		<style>
					
					.header{
							position:relative;
							left:0;
							top:0;
							width: 100%;
							background-color:rgb(223,223,242) ;
							color: purple;
							text-align: center;
							font-family:consolas;
							padding:5px;
	
}
			

					
					.main {
					  margin-left: 140px; 
					  font-size: 50px;
					  color : #400061;
					}

       </style>
					  </head>
				<body>
				
				<body>
		<div class="text-center">
			<h1 class="header"> Shipping Page </h1>
		</div>

		<div class="text-center">
			<a href="mdmanager_shipping.php" class="btn btn-warning">Add Shipping</a>
		    <a href="mdshipping.php" class="btn btn-warning">Update Shipping</a>
		</div>
	
				
				
				   
	</body>
</html>