<?php
    session_start();
    if(!isset($_SESSION["loggedin"])){
        header("Location: mdlogin.php");
    }
?>
<html>

	<head>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	</head>
	
		
<html>
<head>

		<style>
					
					.header{
							position:relative;
							left:0;
							top:0;
							width: 100%;
							background-color:rgb(223,223,242) ;
							color: purple;
							text-align: center;
							font-family:consolas;
							padding:5px;
	
}
			

					
					.main {
					  margin-left: 140px; 
					  font-size: 50px;
					  color : #400061;
					}

       </style>
					  </head>
				<body>
				
				<body>
		<div class="text-center">
			<h1 class="header"> Manager Home Page </h1>
		</div>

		<div class="text-center">
			<a href="mdmanager.php" class="btn btn-primary">Homepage</a>
			<a href="mdMenu.php" class="btn btn-danger">Menu</a>
			<a href="mdOrder.php" class="btn btn-info">Order</a>
			<!--<a href="m_menu.php" class="btn btn-warning">Add Menu</a>
			<a href="updatemenu.php" class="btn btn-danger">Update Menu List </a>--->
			<a href="mdDiscountall.php" class="btn btn-warning">Discount</a>
			<!-- <a href="manager_discount.php" class="btn btn-info">Add Discount</a>
			<a href="discount.php" class="btn btn-primary"> Update Discount</a> --->
			<a href="mdshippingall.php" class="btn btn-success">Shipping</a>
			<!--<a href="manager_shipping.php" class="btn btn-warning">Add Shipping</a>
		    <a href="shipping.php" class="btn btn-warning">Update Shipping</a>--->
			<a href="mdreservationall.php" class="btn btn-primary">Reservation</a>
			<!--<a href="addreservation.php" class="btn btn-info">Add Reservation</a>
			<a href="reservationlist.php" class="btn btn-danger">Update Reservation List </a>--->
				<a href="mddelivery.php" class="btn btn-info">Delivery</a>
			<a href="mdlogin.php" class="btn btn-danger">Logout</a>		
		</div>
		<span><h1 align="center"><i><?php echo "Welcome To Manager Home ";
                            echo $_SESSION["loggedin"];?></i></h1></span>
		<div class = "main">
				<h1 align="center"> <b><i><u>Onoir</u> </i> </b></h1>
				  <img align = "center" src = "images/image1.jpg" height = "457px" width = "1129px">
				  </div>
				
				
				   
	</body>
</html>