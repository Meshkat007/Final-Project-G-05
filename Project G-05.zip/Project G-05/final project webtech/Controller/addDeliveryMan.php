<?php
require_once '../Models/db_connect.php';
require_once '../Models/modelFunction.php';

session_start();
if (!isset($_SESSION['logged_in']) || !isset($_SESSION['userType']) ||  $_SESSION['logged_in']!=1 || $_SESSION['userType']!='admin'){
	header('location:../index.php');
	exit();
}

if (isset($_POST['addDeliveryMan'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];
	$name = $_POST['name'];
	$email = $_POST['email'];
	$dob = $_POST['dob'];
	$gender = $_POST['gender'];

	if (empty($name) || empty($email) || empty($username) || empty($password) || empty($dob) || empty($gender)) {
		$_SESSION['message'] = "<div class='brownAlert'>Field can not be empty!</div><br>";
		header('location:../Views/admins.php');
	}else if (managerEmailExists($conn, $email)) {
		$_SESSION['message'] = "<div class='brownAlert'>Email already exists!</div><br>";
		header('location:../Views/add_manager.php');
	}else if (managerUsernameExists($conn, $username)) {
		$_SESSION['message'] = "<div class='brownAlert'>This username already exists! Try another one</div><br>";
		header('location:../Views/add_manager.php');
	} else{
		if (addDeliveryMan($conn, $_POST)) {
			$_SESSION['message'] = "<div class='greenAlert'>New Delivery man successfully Added!</div><br>";
		}else{
			$_SESSION['message'] = "<div class='brownAlert'>Opps! Error occured with database during insertion!</div><br>";
			
		}
		header('location:../Views/add_delivery_man.php');
	}
}