<?php
session_start();
require_once '../Models/db_connect.php';
require_once '../Models/modelFunction.php';

if (!isset($_SESSION['logged_in']) || !isset($_SESSION['userType']) || ($_SESSION['logged_in']!=1) || ($_SESSION['userType']!='admin')) {
	header('location:../index.php');
	exit();
}

if (isset($_POST['updateShipping'])) {
	$shipping_address = $_POST['shipping_address'];

	$orderId = $_POST['orderId'];

	if (empty($shipping_address)) {
		$_SESSION['message'] = "<div class='brownAlert'>Shipping address can not be empty!</div><br>";
		header('location:../Views/edit_shipping.php?orderId='.$orderId);
	}else{
		if (updateShippingAddress($conn, $_POST)) {
			$_SESSION['message'] = "<div class='greenAlert'>Shipping address Successfully Updated!</div><br>";
		}else{
			$_SESSION['message'] = "<div class='brownAlert'>Failed to update!</div><br>";
		}
		header('location:../Views/edit_shipping.php?orderId='.$orderId);
	}

}