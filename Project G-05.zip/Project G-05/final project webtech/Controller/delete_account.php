<?php
session_start();
if (!isset($_SESSION['logged_in']) || !isset($_SESSION['userType']) ||  ($_SESSION['logged_in']!=1) || ($_SESSION['userType']!='admin')) {
	header('location:../index.php');
	exit();
}
require_once '../Models/db_connect.php';
if (isset($_GET['adminId']) && !empty($_GET['adminId'])) {
	if ($_GET['adminId']==$_SESSION['userId']) {
		$_SESSION['message'] = "<div class='brownAlert'>Sorry! You can't delete yourself!</div><br>";
	}else{
		
		$adminId = $_GET['adminId'];
		$sql = "DELETE FROM admins WHERE id='$adminId'";
		if (mysqli_query($conn,$sql)) {
			$_SESSION['message'] = "<div class='greenAlert'>Admin account successfully deleted!</div><br>";
		}else{
			$_SESSION['message'] = "<div class='brownAlert'>Failed to delete admin account!</div><br>";
		}
	}
	header('location:../Views/admins.php');
}else if (isset($_GET['managerId']) && !empty($_GET['managerId'])) {
	$managerId = $_GET['managerId'];
	$sql1 = "DELETE FROM managers WHERE id='$managerId'";

	if (mysqli_query($conn,$sql1) ) {
		$_SESSION['message'] = "<div class='greenAlert'>Manager account successfully deleted!</div><br>";
	}else{
		$_SESSION['message'] = "<div class='brownAlert'>Failed to delete manager account!</div><br>";
	}
	header('location:../Views/manager_list.php');
}else if (isset($_GET['deliveryManId']) && !empty($_GET['deliveryManId'])) {
	$deliveryManId = $_GET['deliveryManId'];
	$sql1 = "DELETE FROM delivery_man WHERE id='$deliveryManId'";
	if (mysqli_query($conn,$sql1)) {
		$_SESSION['message'] = "<div class='greenAlert'>Delivery man account successfully deleted!</div><br>";
	}else{
		$_SESSION['message'] = "<div class='brownAlert'>Failed to delete delivery man account!</div><br>";
	}
	header('location:../Views/delivery_man_list.php');
}
else{
	header('location:../Views/dashboard.php');
}