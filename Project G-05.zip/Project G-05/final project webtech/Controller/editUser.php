<?php
session_start();
require_once '../Models/db_connect.php';
require_once '../Models/modelFunction.php';

if (!isset($_SESSION['logged_in']) || !isset($_SESSION['userType']) || ($_SESSION['logged_in']!=1) || ($_SESSION['userType']!='admin')) {
	header('location:../index.php');
	exit();
}

if (isset($_POST['changeProfile'])) {
	$name = $_POST['name'];
	$email = $_POST['email'];
	$username = $_POST['username'];

	if (isset($_POST['managerId']) || isset($_POST['deliveryManId'])) {
		$tableName = "";
		$userId = null;
		$paramName = "";
		$paramValue ="";
		if (isset($_POST['managerId']) && !empty($_POST['managerId'])) {
			$tableName = "managers";
			$userId=$_POST['managerId'];
			$paramName="managerId";
			$paramValue=$_POST['managerId'];
		}

		if (isset($_POST['deliveryManId']) && !empty($_POST['deliveryManId'])) {
			$tableName = "delivery_man";
			$userId=$_POST['deliveryManId'];
			$paramName="deliveryManId";
			$paramValue=$_POST['deliveryManId'];
		}



		$error = "";
		$dbError = "";
		if (empty($name) || empty($email)) {
			//exit();
			$_SESSION['message'] = "<div class='brownAlert'>Field can not be empty!</div><br>";
			header('location:../Views/edit_user.php?'.$paramName.'='.$paramValue);
		}else{
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$error .= "Invalid Email format!<br>";
			}
		   		

			if (!empty($error)) {
				$_SESSION['message'] = "<div class='brownAlert'>".$error."</div>";
			}else{
				$sql1 = "UPDATE $tableName SET name='$name', email='$email' WHERE id='$paramValue'";
				if (mysqli_query($conn, $sql1)) {
					$_SESSION['message'] = "<div class='greenAlert'>Successfully Updated!</div><br>";
				}else{
					$_SESSION['message'] = "<div class='brownAlert'>Profile data update failed!</div><br>";
				}
			}
			header('location:../Views/edit_user.php?'.$paramName.'='.$paramValue);
		}
	}else{
		header('location:../index.php');

	}

	
}

if (isset($_POST['changePassword'])) {
	$newPassword = $_POST['newPassword'];
	$newPassword2 = $_POST['newPassword2'];

	if (isset($_POST['managerId']) || isset($_POST['deliveryManId'])) {
		$tableName = "";
		$userId = null;
		$paramName = "";
		$paramValue ="";
		if (isset($_POST['managerId']) && !empty($_POST['managerId'])) {
			$tableName = "managers";
			$userId=$_POST['managerId'];
			$paramName="managerId";
			$paramValue=$_POST['managerId'];
		}

		if (isset($_POST['deliveryManId']) && !empty($_POST['deliveryManId'])) {
			$tableName = "delivery_man";
			$userId=$_POST['deliveryManId'];
			$paramName="deliveryManId";
			$paramValue=$_POST['deliveryManId'];
		}

		if (empty($newPassword) || empty($newPassword2)) {
			$_SESSION['message'] = "<div class='brownAlert'>During password change field should not be empty!</div><br>";
			header('location:../Views/edit_user.php?'.$paramName.'='.$paramValue);
		}else if ($newPassword != $newPassword2) {
			$_SESSION['message'] = "<div class='brownAlert'>New Password and Confirm New Password not matched!</div><br>";
			header('location:../Views/edit_user.php?'.$paramName.'='.$paramValue);
		}else{
			$sql1 = "UPDATE $tableName SET password='$password' WHERE id='$paramValue'";
			if (updatePassword($conn, $tableName, $newPassword, $paramValue)) {
				$_SESSION['message'] = "<div class='greenAlert'>Password Successfully Updated!</div><br>";
			}else{
				$_SESSION['message'] = "<div class='brownAlert'>Password update failed!</div><br>";
			}
			header('location:../Views/edit_user.php?'.$paramName.'='.$paramValue);
		}

	}else{
		header('location:../index.php');

	}

	
}