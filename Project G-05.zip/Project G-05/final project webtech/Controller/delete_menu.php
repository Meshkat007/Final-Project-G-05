<?php
session_start();
if (!isset($_SESSION['logged_in']) || !isset($_SESSION['userType']) ||  ($_SESSION['logged_in']!=1) || ($_SESSION['userType']!='admin')) {
	header('location:../index.php');
	exit();
}
require_once '../Models/db_connect.php';
if (isset($_GET['menuId']) && !empty($_GET['menuId'])) {
	
	$menuId = $_GET['menuId'];
	$sql = "DELETE FROM food_menu WHERE id='$menuId'";
	if (mysqli_query($conn,$sql)) {
		$_SESSION['message'] = "<div class='greenAlert'>Menu item successfully deleted!</div><br>";
	}else{
		$_SESSION['message'] = "<div class='brownAlert'>Failed to delete menu!</div><br>";
	}
	header('location:../Views/menu_list.php');
}