<!DOCTYPE html>
<html>
<head>
	<title>University Management System</title>
</head>
<body>
	<?php require_once "Views/index.php"; ?>
</body>
</html>