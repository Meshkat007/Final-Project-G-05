<?php

$jsonValue = file_get_contents("../Models/about.json");

$teamData = json_decode($jsonValue, true);

?>

<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
</head>
<body bgcolor="black">
	<table border="1" width="100%" cellpadding="10">
		<tr>
			<td align="center" colspan="2" bgcolor="dimgray">
				<h1>
					About Us
				</h1>
			</td>
		</tr>
		<tr height="360px">
			
			<td align="center" bgcolor="dimgray">
				<table width="60%" border="1" cellpadding="6" style="font-size: 17px; font-weight: bold;">
					<tr>
						<td align="center">
							<img src="<?=$teamData['admin']['image']?>" width="200px"><br>
							<?=$teamData['admin']['name']?><br>
							<?=$teamData['admin']['id']?>
						</td>
						<td align="center">
							<img src="<?=$teamData['manager']['image']?>" width="200px"><br>
							<?=$teamData['manager']['name']?><br>
							<?=$teamData['manager']['id']?>
						</td>
					</tr>
					<tr>
						<td align="center">
							<img src="<?=$teamData['customer']['image']?>" width="200px"><br>
							<?=$teamData['customer']['name']?><br>
							<?=$teamData['customer']['id']?>
						</td>
						<td align="center">
							<img src="<?=$teamData['delivery_man']['image']?>" width="200px"><br>
							<?=$teamData['delivery_man']['name']?><br>
							<?=$teamData['delivery_man']['id']?>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td height="65px" bgcolor="dimgray" colspan="3">
				<center>Copyright &copy; Rimi</center>
			</td>
		</tr>
	</table>

</body>
</html>