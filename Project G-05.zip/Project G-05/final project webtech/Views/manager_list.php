<?php
session_start();
require_once '../Models/db_connect.php';
require_once '../Models/modelFunction.php';

if (!isset($_SESSION['logged_in']) || !isset($_SESSION['userType']) ||  $_SESSION['logged_in']!=1) {
	header('location:../index.php');
	exit();
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Manager List</title>
</head>
<body bgcolor="black">
	<table border="1" width="100%" cellpadding="10">
		<tr>
			<td align="center" colspan="2" bgcolor="dimgray">
				<h1>
					Manager List
				</h1>
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<?php include_once 'includes/topbar.php'; ?>
			</td>
		</tr>
		<tr height="360px">
			<td width="25%">
				<?php include_once 'includes/sidebar.php'; ?>
			</td>
			<td align="center" bgcolor="dimgray">
				<table width="100%" border="1">
					<tr>
						<th>Sl.</th>
						<th>Name</th>
						<th>Gender</th>
						<th>DOB</th>
						<th>Email</th>
						<th>User Name</th>
						<th>Action</th>
					</tr>
				<?php 

				$i=0;
				$userDatas = fetchManager($conn);
				if (count($userDatas)==0) {
					echo "<tr><td colspan='5' align='center'>No manager found...</td></tr>";
				}
				foreach ($userDatas as $userData) {
				?>
					<tr>
						<td><?=++$i?></td>
						<td><?=$userData['name']?></td>
						<td><?=$userData['gender']?></td>
						<td><?=$userData['dob']?></td>
						<td><?=$userData['email']?></td>
						<td><?=$userData['username']?></td>
						<td><a href="../Views/edit_user.php?managerId=<?=$userData['id']?>">Edit</a> | <a href="../Controller/delete_account.php?managerId=<?=$userData['id']?>">Delete</a></td>
					</tr>
				<?php } ?>
				</table>

			</td>
		</tr>
		<tr>
			<td height="65px" bgcolor="dimgray" colspan="3">
				<center>Copyright &copy; Rimi</center>
			</td>
		</tr>
	</table>

</body>
</html>
