<?php
session_start();
require_once '../Models/db_connect.php';
require_once '../Models/modelFunction.php';

if (!isset($_SESSION['logged_in']) || !isset($_SESSION['userType']) || ($_SESSION['logged_in']!=1) || ($_SESSION['userType']!='admin')) {
	header('location:../index.php');
	exit();
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>Delivery List</title>
</head>
<body bgcolor="black">
	<table border="1" width="100%" cellpadding="10">
		<tr>
			<td align="center" colspan="2" bgcolor="dimgray">
				<h1>
					Delivery List
				</h1>
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<?php include_once 'includes/topbar.php'; ?>
			</td>
		</tr>
		<tr height="360px">
			<td width="25%">
				<?php include_once 'includes/sidebar.php'; ?>
			</td>
			<td align="center" bgcolor="dimgray">
				<?php if(isset($_SESSION['message']) && !empty($_SESSION['message'])) echo $_SESSION['message']; unset($_SESSION['message']); ?>
				
				<div id="dataTable">
					
				</div>
				<table width="100%" border="1" cellpadding="5" id="mainTable">
					<tr>
						<th width="1%">Sl. No</th>
						<th>Order ID</th>
						<th >Delivery Man</th>
						<th>Action</th>
					</tr>
			<?php
			$deliveryDatas = fetchDelivery($conn);
			// print_r(fetchTeachers($conn));
			// exit();
			$i=0;
			if (count($deliveryDatas)==0) {
				echo "<tr><td colspan='5' align='center'>No delivery data found...</td></tr>";
			}
			foreach ($deliveryDatas as $deliveryData) {
			?>
					<tr>
						<td><?=++$i?></td>
						<td><?=$deliveryData['order_id']?></td>
						<td><?=fetchDeliveryMan($conn, $deliveryData['delivery_man_id'])['name']?></td>
						<td>[<a href="edit_shipping.php?orderId=<?=$deliveryData['order_id']?>">View Order</a>]</td>
					</tr>
					<?php } ?>
				</table>
			</td>
		</tr>
		<tr>
			<td height="65px" bgcolor="dimgray" colspan="3">
				<center>Copyright &copy; Rimi</center>
			</td>
		</tr>
	</table>
</body>
</html>