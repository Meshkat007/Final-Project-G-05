<?php
$conn = mysqli_connect('localhost','root','','rms_rimi');
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

?>