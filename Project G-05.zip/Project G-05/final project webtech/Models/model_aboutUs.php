<?php
$teams = [
	[
		'name'=>'Sanjeda Easmin Rimi',
		'id'=>'18-36122-1',
		'image'=>'../Uploads/TeamMember/rimi.jpg',
	],
	[
		'name'=>'MD Meshkatur Rahman',
		'id'=>'18-38672-3',
		'image'=>'../Uploads/TeamMember/meshkat.jpg',
	],
	[
		'name'=>'Suraiya Jahan Chowa',
		'id'=>'17-35523-3',
		'image'=>'../Uploads/TeamMember/chowa.jpg',
	],
	[
		'name'=>'MD Shohidul Islam Tarek',
		'id'=>'18-38690-3',
		'image'=>'../Uploads/TeamMember/tareq.jpg',
	]
	
];

echo json_encode($teams);

echo "<br>";

$jsonVal = file_get_contents("about.json");

print_r(json_decode($jsonVal, true));

?>