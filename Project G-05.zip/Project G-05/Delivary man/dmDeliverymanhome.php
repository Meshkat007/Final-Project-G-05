<html>
<head>

		<style>
				body {
				  font-family: consolas;
				}
				
				.sidenav {
				  height: 100%;
				  width: 200px;
				  position: fixed;
				  z-index: 1;
				  top: 0;
				  left: 0;
				  background-color: #C6B1DC;
				  
				  padding-top: 20px;
				}

				.sidenav a {
				  padding: 6px 8px 6px 16px;
				  text-decoration: none;
				  font-size: 30px;
				  color: #431D58;
				  display: block;
				}

				.sidenav a:hover {
				  color: #F7F7F7;
				}

					.main {
					  margin-left: 200px; 
					  font-size: 50px;
					  color : #400061;
					}

       </style>
					  </head>
				<body>

				<div class="sidenav">
				  <a href="dmDeliverymanhome.php">Home</a>
				  <a href="dmProfile.php">Add Profile</a>
				  <a href="dmprofile1.php">Profile</a>
				  <a href="dmmanage_shipping.php">Shipping info</a>
				  <a href="dmHistory.php">History</a>
				  <a href="dmlogin.php"> Log out </a>
				  
				</div>

				<div class="main">
				  <h1 align = "center "> <b> <i> <u> Onoir </u> </i> </b></h1>
				  <img align = "center" src = "image1.jpg" height = "490px" width = "1350px">
				  
				 </div> 
				   
	</body>
</html>