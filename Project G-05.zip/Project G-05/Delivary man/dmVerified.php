<html>
    <head>
	     <style>
		    body{
				background-color:rgb(223,223,242);
			}
			.my-font{
				font-size:35px;
				font-family:consolas;
			}
			.my-text-field{
				width:200px;
			}
			
		
		</style>
	</head>
    <body>
				    
					<tr>
				        <td><h1 align="center">Shipping Verified Successfully</h1></td>
			        </tr>
				    
				</table>
     </body>
</html>
